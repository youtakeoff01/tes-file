package com.hand.anji.streaming.utils

import java.sql.{Connection, DriverManager}
import java.util.LinkedList

import org.slf4j.LoggerFactory

/**
  * Created by zgl on 2017/4/17.
  */
object JdbcUtil extends Serializable {
  private val connectionPool = new LinkedList[Connection]()
  private val logger = LoggerFactory.getLogger(JdbcUtil.getClass)

  def init(url: String, user: String, pwd: String) = {
    logger.info("initing the connect pool")
    AnyRef.synchronized({
      if (connectionPool.isEmpty) {
        for (i <- 0 to 10) {
          try {
            classOf[com.mysql.jdbc.Driver]
            val conn = DriverManager.getConnection(url, user, pwd)
            connectionPool.add(conn)
          } catch {
            case e: Exception => logger.error("fail to get mysql connection:", e)
          }
        }
      }
    })
    logger.info("success init the connect pool")

  }

  def getConnection(): Connection = {
    connectionPool.poll()
  }

  def releaseConn(conn: Connection): Unit = {
    connectionPool.push(conn)
  }

}
