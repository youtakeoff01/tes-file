package com.hand.anji.streaming.utils

import com.alibaba.fastjson.JSONObject
import kafka.serializer.Decoder
import com.alibaba.fastjson.JSON
import kafka.utils.VerifiableProperties

/**
  * Created by zgl on 2017/4/19.
  */
class JsonDecoder(verifiableProperties: VerifiableProperties) extends Decoder[JSONObject] {

  override def fromBytes(bytes: Array[Byte]): JSONObject = {
    JSON.parseObject(new String(bytes))
  }
}
