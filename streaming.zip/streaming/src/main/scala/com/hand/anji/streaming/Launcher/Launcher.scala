package com.hand.anji.streaming.Launcher

import java.util.concurrent.atomic.AtomicReference

import com.hand.anji.streaming.config.ConfigManager
import com.hand.anji.streaming.handler.DeliveryHandler
import com.hand.anji.streaming.service.{OffsetService, ZkService}
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.kafka.OffsetRange
import org.slf4j.LoggerFactory

/**
  * Created by zgl on 2017/8/22.
  */
object Launcher {
  def main(args: Array[String]): Unit = {
    System.setProperty("hadoop.home.dir", "D:\\winutils\\winutils")
    val logger = LoggerFactory.getLogger(Launcher.getClass)
    var scc = null.asInstanceOf[StreamingContext]
    try {
      val conf = ConfigManager.getConfig()
      val offsetRanges = new AtomicReference[Array[OffsetRange]]()
      val offsetService = new OffsetService(offsetRanges, new ZkService(conf.zookeeperConf.zkServerString, conf.zookeeperConf.timeout.toInt))
      val tupleStream = offsetService.getStreamingContext(conf, false)
      scc = tupleStream._1
      val kStream = tupleStream._2
      val handler = new DeliveryHandler("jdbc:mysql://10.188.50.70:3306/test?useUnicode=true&characterEncoding=utf8&useSSL=false&autoReconnect=true", "zgl", "123654")
      handler.process(kStream)
    } catch {
      case e: Exception => logger.error("failed to create streamingContext:", e)
    }

    scc.start()
    scc.awaitTermination()

  }
}

