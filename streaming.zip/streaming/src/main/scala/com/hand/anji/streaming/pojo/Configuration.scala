package com.hand.anji.streaming.pojo

/**
  * Created by zgl on 2017/8/20.
  */
case class SparkDefaultConf(appName: String, runMode: String, batchDuration: Long, maxBatch: Long)

case class KafkaDefaultConf(brokerList: List[String], port: Int, topics: List[String], groupId: String, reset: String, kafkaServerString: String)

case class ZookeeperDefaultConf(zkConnect: List[String], port: Int, nodePath: String, timeout: Long, zkServerString: String)

case class HdfsDefaultConf(user: String, rootPath: String)

class Configuration(sc: SparkDefaultConf, kc: KafkaDefaultConf, zc: ZookeeperDefaultConf, hc: HdfsDefaultConf) extends Serializable {
  val sparkDefaultConf = this.sc
  val kafkaConf = this.kc
  val zookeeperConf = this.zc
  val hdfsConf = this.hc
}
