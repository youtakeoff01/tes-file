package com.hand.anji.streaming.listener

import java.time.LocalDateTime

import com.hand.anji.streaming.service.{OffsetService, ZkService}
import com.hand.anji.streaming.utils.ZkUtils
import org.apache.commons.lang.StringUtils
import org.apache.spark.streaming.scheduler._
import org.slf4j.LoggerFactory

/**
  * Created by zgl on 2017/8/24.
  */
class ConsumerListener(offsetService: OffsetService, zkService: ZkService) extends StreamingListener with Serializable {
  private val logger = LoggerFactory.getLogger(classOf[ConsumerListener])

  override def onReceiverStarted(receiverStarted: StreamingListenerReceiverStarted): Unit = {
    super.onReceiverStarted(receiverStarted)
    logger.info("trying to delete yesterday flag")
    deleteSuccessFlag()
    logger.info("success to delete the all flag of yesterday")
  }

  override def onReceiverError(receiverError: StreamingListenerReceiverError): Unit = {
    super.onReceiverError(receiverError)
    logger.error("task failed on executor:" + receiverError.receiverInfo.executorId, receiverError.receiverInfo.lastError)
  }

  override def onReceiverStopped(receiverStopped: StreamingListenerReceiverStopped): Unit = super.onReceiverStopped(receiverStopped)

  override def onBatchSubmitted(batchSubmitted: StreamingListenerBatchSubmitted): Unit = super.onBatchSubmitted(batchSubmitted)

  override def onBatchStarted(batchStarted: StreamingListenerBatchStarted): Unit = super.onBatchStarted(batchStarted)

  override def onBatchCompleted(batchCompleted: StreamingListenerBatchCompleted): Unit = {
    super.onBatchCompleted(batchCompleted)
    logger.info("start to save this batch flag")
    val pathTree = ZkUtils.getFlagPath()
    try {
      val flag = saveFlag(pathTree(pathTree.length - 1))
      if (!flag) {
        logger.info("failed to create the success flag:" + flag)
        zkService.createNode(pathTree(pathTree.length - 1), false.toString)
      }
    } catch {
      case e: Exception => {
        logger.info("init the first batch flag path")
        for (i <- 0 until pathTree.length - 1) {
          zkService.createNode(pathTree(i), null)
        }
      }
    }
  }

  def saveFlag(path: String): Boolean = {
    zkService.createNode(path, true.toString)
  }

  def deleteSuccessFlag(): Boolean = {
    val yesterday = LocalDateTime.now().minusDays(1)
    val year = yesterday.getYear
    val month = yesterday.getMonth.getValue
    val day = yesterday.getDayOfMonth
    val path = "/" + year + "/" + month + "/" + day
    try {
      kafka.utils.ZkUtils.getChildren(zkService.client, path).foreach(c => {
        if (StringUtils.equalsIgnoreCase(zkService.read(path + "/" + c), "true")) {
          zkService.deleteNode(c)
        }
      })
      return true
    } catch {
      case e: Exception => logger.error("fail to delete the flag:", e)
    }
    false
  }

}

