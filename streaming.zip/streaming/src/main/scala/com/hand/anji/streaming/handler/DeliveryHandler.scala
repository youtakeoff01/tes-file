package com.hand.anji.streaming.handler

import java.sql.Date
import java.text.SimpleDateFormat
import java.util.Properties

import com.alibaba.fastjson.{JSON, JSONObject}
import com.hand.anji.streaming.utils.JdbcUtil
import org.apache.kudu.client.KuduTable
import org.apache.kudu.spark.kudu._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Column, DataFrame, SQLContext}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.streaming.dstream.{DStream, InputDStream}

/**
  * Created by zgl on 2017/8/24.
  */
class DeliveryHandler(url: String, user: String, pwd: String) extends Serializable {

  final val pro = new Properties()
  pro.setProperty("user", user)
  pro.setProperty("password", pwd)
  pro.setProperty("driver", "com.mysql.jdbc.Driver")

  JdbcUtil.init(url, user, pwd)

  def process(inputDStream: InputDStream[(String, String)]) = {
    val format = new SimpleDateFormat("yyyy-MM-dd")
    val dateString = format.format(new Date(System.currentTimeMillis()))
    //初始化数据库
    val initSql = s"insert into jsstream values ('${dateString}',0,0)"
    insert(initSql)
    val table = getStreamByTable("AUTO_SUPPLY_INTERFACE", inputDStream)
    val jsonTable = transfer2JSON(table)
    val updateDS = filterOper("U", jsonTable)
    val updateSRDS = updateDS.map(t => {
      val beforeData = getSubJSON("before", t._2)
      val afterData = getSubJSON("after", t._2)
      val beforeSend: Long = if (beforeData.getLong("QTY") == null) 0L else beforeData.getLong("QTY")
      val beforeRecieve: Long = if (beforeData.getLong("RECEIVE_QTY") == null) 0L else beforeData.getLong("QTY")
      val afterSend: Long = if (afterData.getLong("QTY") == null) 0L else afterData.getLong("QTY")
      val afterRecieve: Long = if (afterData.getLong("RECEIVE_QTY") == null) 0L else afterData.getLong("QTY")
      ((afterSend - beforeSend), (afterRecieve - beforeRecieve))
    }).filter(t => t._1 != 0 || t._2 != 0)
    val insertDS = filterOper("I", jsonTable)
    val insertSRDS = insertDS.map(t => {
      val insertData = getSubJSON("after", t._2)
      val send = if (insertData.getLong("QTY") == null) 0L else insertData.getLong("QTY")
      val recieve = if (insertData.getLong("RECEIVE_QTY") == null) 0L else insertData.getLong("QTY")
      (send, recieve)
    }).filter(t => t._1 != 0 || t._2 != 0)
    val finalDS = insertSRDS.union(updateSRDS.asInstanceOf[DStream[(Any, Any)]])

    finalDS.foreachRDD(rdd => {
      val longRdd = rdd.asInstanceOf[RDD[(Long, Long)]]
      //有数据再处理，否则什么也不做
      val count = longRdd.count()
      println("当前批次数据量==================>" + count)
      if (count == 0) {

      } else {
        val sqlContext = SQLContext.getOrCreate(rdd.sparkContext)
        import sqlContext.implicits._
        val map = query(s"select * from jsstream where oper_date = '${dateString}'")
        val previousData = map.getOrElse(dateString, (0L, 0L))
        println("数据库当前数据为===============>" + previousData)
        val prePlan = previousData._2
        val preActual = previousData._1
        val df = longRdd.toDF("allPlanNum", "allActaulNum").agg(sum("allPlanNum").as("allPlanNum"), sum("allActaulNum").as("allActaulNum"))
        df.show()
        df.foreach(row => {
          val allPlan = prePlan + row.getLong(0)
          val allAc = preActual + row.getLong(1)
          val sql = s"update jsstream set allPlanNum = ${allPlan},allActaulNum = ${allAc} where oper_date = '${dateString}'"
          update(sql)
        })
      }
    })
    insertDS.foreachRDD(rdd => {
      val insertData = rdd.map(t => getSubJSON("after", t._2).toJSONString.toLowerCase)
      val sqlContext = SQLContext.getOrCreate(insertData.sparkContext)
      var insertDF = sqlContext.read.json(insertData)
      val correctDF = correctJsonType(insertDF)
      if (correctDF != null) {
        insertDF = correctDF
      }
      val kuduContext = new KuduContext("10.102.4.8:7051")
      kuduContext.insertIgnoreRows(insertDF, "impala::impala_kudu_test.AUTO_SUPPLY_INTERFACE_KUDU")
    })
    updateDS.foreachRDD(rdd => {
      val updateData = rdd.map(t => getSubJSON("after", t._2).toJSONString.toLowerCase)
      val sqlContext = SQLContext.getOrCreate(updateData.sparkContext)
      var updateDF = sqlContext.read.json(updateData)
      val correctDF = correctJsonType(updateDF)
      if (correctDF != null) {
        updateDF = correctDF
      }
      //      updateDF.printSchema()
      val kuduContext = new KuduContext("10.102.4.8:7051")
      kuduContext.upsertRows(updateDF, "impala::impala_kudu_test.AUTO_SUPPLY_INTERFACE_KUDU")
    })


  }

  def correctJsonType(data: DataFrame): DataFrame = {
    var correctedDF = data
    val filterSchema = correctedDF.schema.filter(s => {
      s.name.contains("qty")
    })
    if (filterSchema.size != 0) {
      val numberFieldCol = filterSchema.map(f => (f.name, correctedDF.col(f.name).cast(DataTypes.LongType))).toArray
      for (tuple <- numberFieldCol) {
        correctedDF = correctedDF.withColumn(tuple._1 + "000", tuple._2).drop(tuple._1).withColumnRenamed(tuple._1 + "000", tuple._1)
      }
    }
    correctedDF
  }

  def filterOper(operType: String, data: DStream[(String, JSONObject)]): DStream[(String, JSONObject)] = {
    data.filter(t => t._2.getString("op_type").equalsIgnoreCase(operType))
  }

  def getStreamByTable(tableName: String, inputDStream: InputDStream[(String, String)]): DStream[(String, String)] = {
    inputDStream.filter(x => {
      x._2.contains(tableName)
    })
  }

  def transfer2JSON(stream: DStream[(String, String)]): DStream[(String, JSONObject)] = {
    stream.transform(rdd => {
      rdd.map(x => {
        (x._1, JSON.parseObject(x._2))
      })
    })
  }

  def getSubJSON(subJsonField: String, jSONObject: JSONObject): JSONObject = {
    val jsonString = jSONObject.getString(subJsonField)
    JSON.parseObject(jsonString)
  }


  def update(sql: String): Unit = {
    val conn = JdbcUtil.getConnection()
    try {
      val ps = conn.prepareStatement(sql)
      ps.executeUpdate()
      ps.close()
      JdbcUtil.releaseConn(conn)
    } catch {
      case e: Exception => e.printStackTrace()
    }

  }

  def insert(sql: String): Unit = {
    val conn = JdbcUtil.getConnection()
    try {
      val ps = conn.prepareStatement(sql)
      ps.execute()
      ps.close()
      JdbcUtil.releaseConn(conn)
    } catch {
      case e: Exception => e.printStackTrace()
    }

  }

  def query(sql: String): Map[String, (Long, Long)] = {
    val conn = JdbcUtil.getConnection()
    var data = Map[String, (Long, Long)]()
    try {
      val ps = conn.prepareStatement(sql)
      val rs = ps.executeQuery()
      while (rs.next()) {
        val id = rs.getString(1)
        val actualCount = rs.getLong(2)
        val planCount = rs.getLong(3)
        data += (id -> (actualCount, planCount))
      }
      ps.close()
      rs.close()
      JdbcUtil.releaseConn(conn)
      data
    } catch {
      case e: Exception => {
        e.printStackTrace()
        data
      }
    }
  }
}
