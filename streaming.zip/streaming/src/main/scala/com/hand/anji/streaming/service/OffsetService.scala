package com.hand.anji.streaming.service

import java.util.concurrent.atomic.AtomicReference

import com.alibaba.fastjson.JSONObject
import com.hand.anji.streaming.handler.DeliveryHandler
import com.hand.anji.streaming.pojo.{Configuration, SparkDefaultConf}
import com.hand.anji.streaming.utils.JsonDecoder
import kafka.api.{OffsetRequest, PartitionOffsetRequestInfo, TopicMetadataRequest}
import kafka.common.TopicAndPartition
import kafka.consumer.SimpleConsumer
import kafka.message.MessageAndMetadata
import kafka.serializer.StringDecoder
import kafka.utils.ZKGroupTopicDirs
import org.apache.commons.lang.StringUtils
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka.{HasOffsetRanges, KafkaUtils, OffsetRange}
import org.apache.spark.streaming.{Milliseconds, StreamingContext}
import org.slf4j.LoggerFactory

/**
  * Created by zgl on 2017/9/04.
  */
class OffsetService(offsetRanges: AtomicReference[Array[OffsetRange]], zkService: ZkService) extends Serializable {
  private val logger = LoggerFactory.getLogger(classOf[OffsetService])

  def getLeaderAndPartition(topics: Set[String], brokerHost: String): Map[Int, String] = {
    val rq = new TopicMetadataRequest(topics.toSeq, 0)
    val leaderConsumer = new SimpleConsumer(brokerHost, 9092, 6000, 1024, "getLeader")
    val rs = leaderConsumer.send(rq)
    val metadataOption = rs.topicsMetadata.headOption
    val partitions = metadataOption match {
      case Some(mo) => mo.partitionsMetadata.map(mo => (mo.partitionId, mo.leader.get.host)).toMap[Int, String]
      case None => Map[Int, String]()
    }
    partitions
  }

  private def getLastOffset(group: String, topic: Set[String], path: String, brokerHost: String): Map[TopicAndPartition, Long] = {

    val leaderWithPartition = getLeaderAndPartition(topic, brokerHost)
    leaderWithPartition.map(f => {
      val partition = f._1
      val leader = f._2
      val partitionOffset = zkService.read(path + "/" + partition)
      val tp = TopicAndPartition(topic.head, partition)
      val requestMin = OffsetRequest(Map(tp -> PartitionOffsetRequestInfo(OffsetRequest.EarliestTime, 1)))
      val consumerMin = new SimpleConsumer(leader, 9092, 6000, 1024, "getMinOffset")
      val currentOffset = consumerMin.getOffsetsBefore(requestMin).partitionErrorAndOffsets(tp).offsets
      var nextOffset = null.asInstanceOf[Long]
      if (StringUtils.isNotEmpty(partitionOffset)) {
        nextOffset = partitionOffset.toLong
      }
      //修改offset越界
      if (currentOffset.length > 0 && nextOffset < currentOffset.head) {
        nextOffset = currentOffset.head
      }
      logger.info("next offset is :" + nextOffset)
      (tp, nextOffset)
    })

  }

  private def getOffsetRanges(kStream: InputDStream[(String, String)]): AtomicReference[Array[OffsetRange]] = {
    kStream.foreachRDD(rdd => {
      val offsetRangeArray = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
      offsetRanges.set(offsetRangeArray)
    })
    offsetRanges
  }

  def updateOffset(kStream: InputDStream[(String, String)], zKPath: String): Boolean = {
    val offsetRanges = getOffsetRanges(kStream)
    val zkClient = zkService.client
    kStream.foreachRDD(rdd => {
      for (o <- offsetRanges.get()) {
        val path = s"${zKPath}/${o.partition}"
        kafka.utils.ZkUtils.updatePersistentPath(zkClient, path, o.fromOffset.toString)
        logger.info(s" update topic  ${o.topic}  partition ${o.partition}  fromoffset ${o.fromOffset}  untiloffset ${o.untilOffset} ")
      }
    })
    true
  }

  def getStreamingContext(configuration: Configuration, isFromOffset: Boolean): (StreamingContext, InputDStream[(String, String)]) = {
    val sparkDefaultConf = configuration.sparkDefaultConf
    val kafkaConf = configuration.kafkaConf
    val conf = new SparkConf().setAppName(sparkDefaultConf.appName)
    sparkDefaultConf match {
      case SparkDefaultConf(_, "local", _, _) => conf.setMaster("local[*]")
      case SparkDefaultConf(_, "yarn", _, _) => conf.setMaster("yarn-client")
      case SparkDefaultConf(_, _, _, _) => {
        logger.error("unknown spark run mode,system exit with code -1,please check your config file")
        System.exit(-1)
      }
    }
    conf.set("spark.streaming.kafka.maxRatePerPartition", sparkDefaultConf.maxBatch.toString)

    val ssc = new StreamingContext(conf, Milliseconds(2000))
    var kStream = null.asInstanceOf[InputDStream[(String, String)]]
    var kafkaParam = Map("metadata.broker.list" -> kafkaConf.kafkaServerString)
    val topics = kafkaConf.topics.toSet
    if (isFromOffset) {
      val messageHandler = (mmd: MessageAndMetadata[String, String]) => (mmd.topic, mmd.message())
      val zKGroupTopicDirs = new ZKGroupTopicDirs(kafkaConf.groupId, topics.head)
      val zKPath = s"${zKGroupTopicDirs.consumerOffsetDir}"
      val fromOffset = getLastOffset(kafkaConf.groupId, topics, zKPath, kafkaConf.brokerList.head)
      kStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder, (String, String)](ssc, kafkaParam, fromOffset, messageHandler)
      //      val flag = updateOffset(kStream, zKPath)
      //      logger.info("update offset flag is " + flag)
    } else {
      kafkaParam += ("auto.offset.reset" -> kafkaConf.reset)
      kStream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParam, topics)
    }

    //    val dh = new DeliveryHandler("jdbc:mysql://10.211.55.155:3306/test?useUnicode=true&characterEncoding=utf8&useSSL=false&autoReconnect=true", "jsStream", "zgl", "123654")
    //    dh.process(kStream)
    (ssc, kStream)
  }

}
