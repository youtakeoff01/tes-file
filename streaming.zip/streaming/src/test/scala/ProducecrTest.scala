import java.util
import java.util.Properties

import com.alibaba.fastjson.JSONObject
import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.kafka.common.serialization.{Serializer, StringSerializer}


/**
  * Created by zgl on 2017/4/19.
  */
//case class Person(id: Int, name: String, gender: String)

object ProducecrTest {
  def main(args: Array[String]): Unit = {
    val p = new Properties()
    p.put("client.id", "ueba_test");
    p.put("bootstrap.servers", "127.0.0.1:9092");
    p.put("max.request.size", "10485760");
    p.put("compression.type", "snappy");
    val producer = new KafkaProducer[String, JSONObject](p, new StringSerializer(), new Serializer[JSONObject] {
      override def configure(map: util.Map[String, _], b: Boolean): Unit = ???

      override def serialize(s: String, t: JSONObject): Array[Byte] = {
        JSON.toJSONBytes(t, SerializerFeature.WriteMapNullValue, SerializerFeature.WriteNullListAsEmpty)
      }

      override def close(): Unit = ???
    })
    for (i <- 0 to 100000) {
      i match {
        case i if (i % 2 == 0) => producer.send(new ProducerRecord[String, JSONObject]("test", i + "", JSON.parseObject(JSON.toJSONString(new Person(i, "zgl" + i, "F"), SerializerFeature.WriteMapNullValue, SerializerFeature.WriteNullListAsEmpty))))
        case i if (i % 2 != 0) => producer.send(new ProducerRecord[String, JSONObject]("test", i + "", JSON.parseObject(JSON.toJSONString(new Person(i, "ls" + i, "M"), SerializerFeature.WriteMapNullValue, SerializerFeature.WriteNullListAsEmpty))))
      }

    }
  }

}
