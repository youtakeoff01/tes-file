import java.util.Properties

import kafka.consumer.{Consumer, ConsumerConfig}
import kafka.message.Message


/**
  * Created by zgl on 2017/8/31.
  */
object ConsumerTest {
  def main(args: Array[String]): Unit = {
    val pro = new Properties()
    pro.put("zookeeper.connect", "10.102.4.10:2181")
    pro.put("zookeeper.connectiontimeout.ms", "1000000")
    pro.put("group.id", "test_group")
    pro.put("auto.offset.reset", "smallest")
    val consumerConfig = new ConsumerConfig(pro)
    val conn = Consumer.create(consumerConfig)
    println(conn)
    val dataMap = conn.createMessageStreams(Map("test001" -> 3))
    val streams = dataMap.get("test001").get
    println(streams.size)
    for (stream <- streams) {
      for (mesAndMd <- stream) {
        println(mesAndMd.topic)

        val ms = mesAndMd.message()
        val message = new Message(ms)
        val buffer = message.payload
        buffer.get(new Array[Byte](message.payloadSize))
        val tmp = String.valueOf(buffer)
        println("===================>" + tmp)
      }
    }
  }
}
