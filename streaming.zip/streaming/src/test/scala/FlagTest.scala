import java.util.concurrent.atomic.AtomicReference

import com.alibaba.fastjson.JSON
import com.hand.anji.streaming.handler.DeliveryHandler
import com.hand.anji.streaming.service.{OffsetService, ZkService}
import org.apache.spark.streaming.kafka.OffsetRange

/**
  * Created by zgl on 2017/4/28.
  */
object FlagTest {
  def main(args: Array[String]): Unit = {
    //        val offsetRanges = new AtomicReference[Array[OffsetRange]]()
    //        val offsetService = new OffsetService(offsetRanges, new ZkService("hadoop001.edcs.org:2181,hadoop002.edcs.org:2181,hadoop003.edcs.org:2181", 6000))
    //        val map = offsetService.getLeaderAndPartition(Set("jlTest"), "hadoop004.edcs.org")
    //        println("======================>"+map.mkString)
    val jsonString = "{'date':'2017-07-22 21:19:26.679000000'}"
    val json = JSON.parseObject(jsonString)
    val date = json.getDate("date")

    println(date)
    //    val rq = new TopicMetadataRequest(Seq("jlTest"), 0)
    //    val consumerMin = new SimpleConsumer("192.168.11.190", 6667, 6, 10000, "getMinOffset")
    //    val tmr = consumerMin.send(rq)
    //    println("================>" + tmr.topicsMetadata.headOption.get)
    //    val zKGroupTopicDirs = new ZKGroupTopicDirs("hdfs", "test")
    //
    //    val zKPath = s"${zKGroupTopicDirs.consumerOffsetDir}"
    //
    //    val zkService = new ZkService("127.0.0.1:2181", 6000)
    //    val children = zkService.client.countChildren("/2017/4/28")
    //    val childre = kafka.utils.ZkUtils.getChildren(zkService.client, "/2017/4/28")
    //    for (i <- 0 to childre.length - 1) {
    //      println("子目录为==================>" + childre(i))
    //      println("子目录数据为===========>"+zkService.read("/2017/4/28"+"/"+childre(i)))
    //    }
    //    if (children >= 0) {
    //      for (i <- 0 to children) {
    //        //println("path ===============>" + (zKPath + "/" + i))
    //        println("保存的数据为=======>" + zkService.read("/2017/4/28"))
    //      }
    //    }
  }
}
